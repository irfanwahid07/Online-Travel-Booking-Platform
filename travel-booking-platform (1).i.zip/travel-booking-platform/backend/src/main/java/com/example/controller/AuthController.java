package com.example.travel.controller;

import com.example.travel.dto.LoginRequest;
import com.example.travel.dto.RegisterRequest;
import com.example.travel.model.User;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    // simple in-memory user "database"
    private final Map<String, User> users = new ConcurrentHashMap<>();

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest request) {
        if (users.containsKey(request.getUsername())) {
            return ResponseEntity.badRequest().body(Map.of("message", "Username already exists"));
        }
        User user = new User(request.getUsername(), request.getPassword(),
                request.getFullName(), request.getEmail());
        users.put(request.getUsername(), user);
        return ResponseEntity.ok(Map.of(
                "message", "Registration successful",
                "username", user.getUsername()
        ));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        User user = users.get(request.getUsername());
        if (user == null || !user.getPassword().equals(request.getPassword())) {
            return ResponseEntity.status(401).body(Map.of("message", "Invalid username or password"));
        }
        // For demo token is just username
        return ResponseEntity.ok(Map.of(
                "message", "Login successful",
                "token", user.getUsername(),
                "username", user.getUsername(),
                "fullName", user.getFullName()
        ));
    }
}
