package com.example.travel.controller;

import com.example.travel.dto.BookingRequest;
import com.example.travel.model.Trip;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/api")
public class TripController {

    private final List<Trip> trips = new ArrayList<>();
    private final Map<String, List<Trip>> bookingsByUser = new ConcurrentHashMap<>();

    public TripController() {
        // sample data
        trips.add(new Trip(1L, "Goa, India", "3 nights beach holiday with breakfast", 15999.0, "2025-12-10", "2025-12-13"));
        trips.add(new Trip(2L, "Manali, India", "Snowy mountains & adventure sports", 18999.0, "2026-01-05", "2026-01-09"));
        trips.add(new Trip(3L, "Dubai, UAE", "City tour with desert safari", 49999.0, "2026-02-12", "2026-02-16"));
    }

    @GetMapping("/trips")
    public List<Trip> getTrips() {
        return trips;
    }

    @PostMapping("/bookings")
    public ResponseEntity<?> createBooking(
            @RequestHeader("X-Auth-User") String username,
            @RequestBody BookingRequest request) {

        Optional<Trip> tripOpt = trips.stream()
                .filter(t -> t.getId().equals(request.getTripId()))
                .findFirst();

        if (tripOpt.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Trip not found"));
        }

        Trip trip = tripOpt.get();
        bookingsByUser.computeIfAbsent(username, k -> new ArrayList<>()).add(trip);

        return ResponseEntity.ok(Map.of(
                "message", "Booking successful",
                "tripId", trip.getId(),
                "destination", trip.getDestination()
        ));
    }

    @GetMapping("/bookings")
    public ResponseEntity<?> getBookings(@RequestHeader("X-Auth-User") String username) {
        List<Trip> bookings = bookingsByUser.getOrDefault(username, Collections.emptyList());
        return ResponseEntity.ok(bookings);
    }
}
