const API_BASE = "http://localhost:8080/api";

const navHome = document.getElementById("nav-home");
const navTrips = document.getElementById("nav-trips");
const navBookings = document.getElementById("nav-bookings");
const homeSection = document.getElementById("home-section");
const tripsSection = document.getElementById("trips-section");
const bookingsSection = document.getElementById("bookings-section");
const authSection = document.getElementById("auth-section");
const exploreBtn = document.getElementById("explore-btn");
const tripsContainer = document.getElementById("trips-container");
const bookingsContainer = document.getElementById("bookings-container");
const noBookingsText = document.getElementById("no-bookings");

const btnLogin = document.getElementById("btn-login");
const btnLogout = document.getElementById("btn-logout");
const welcomeText = document.getElementById("welcome-text");

const loginUsername = document.getElementById("login-username");
const loginPassword = document.getElementById("login-password");
const loginSubmit = document.getElementById("login-submit");

const regFullName = document.getElementById("reg-fullname");
const regEmail = document.getElementById("reg-email");
const regUsername = document.getElementById("reg-username");
const regPassword = document.getElementById("reg-password");
const registerSubmit = document.getElementById("register-submit");

const toast = document.getElementById("toast");

function showSection(section) {
    [homeSection, tripsSection, bookingsSection, authSection].forEach(sec => sec.classList.add("hidden"));
    section.classList.remove("hidden");
}

function showToast(message) {
    toast.textContent = message;
    toast.classList.remove("hidden");
    setTimeout(() => toast.classList.add("hidden"), 2500);
}

function saveUserToLocal(user) {
    localStorage.setItem("travelUser", JSON.stringify(user));
}

function getUserFromLocal() {
    const text = localStorage.getItem("travelUser");
    if (!text) return null;
    try {
        return JSON.parse(text);
    } catch {
        return null;
    }
}

function clearUserLocal() {
    localStorage.removeItem("travelUser");
}

function saveBookingsLocal(bookings) {
    localStorage.setItem("travelBookings", JSON.stringify(bookings));
}

function getBookingsLocal() {
    const text = localStorage.getItem("travelBookings");
    if (!text) return [];
    try {
        return JSON.parse(text);
    } catch {
        return [];
    }
}

function updateAuthUI() {
    const user = getUserFromLocal();
    if (user) {
        welcomeText.textContent = `Hi, ${user.fullName || user.username}`;
        btnLogin.classList.add("hidden");
        btnLogout.classList.remove("hidden");
    } else {
        welcomeText.textContent = "";
        btnLogin.classList.remove("hidden");
        btnLogout.classList.add("hidden");
    }
}

async function fetchTrips() {
    const res = await fetch(`${API_BASE}/trips`);
    const data = await res.json();
    renderTrips(data);
    return data;
}

function renderTrips(trips) {
    tripsContainer.innerHTML = "";
    trips.forEach(trip => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <h3>${trip.destination}</h3>
            <p class="muted">${trip.description}</p>
            <p>Date: ${trip.startDate} to ${trip.endDate}</p>
            <p class="price">₹${trip.price.toLocaleString()}</p>
            <button class="btn primary book-btn" data-id="${trip.id}">Book Now</button>
        `;
        tripsContainer.appendChild(card);
    });

    document.querySelectorAll(".book-btn").forEach(btn => {
        btn.addEventListener("click", () => handleBookClick(btn.dataset.id));
    });
}

async function handleBookClick(tripId) {
    const user = getUserFromLocal();
    if (!user) {
        showToast("Please login to book a trip.");
        showSection(authSection);
        return;
    }

    try {
        const res = await fetch(`${API_BASE}/bookings`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-Auth-User": user.username
            },
            body: JSON.stringify({ tripId: Number(tripId) })
        });

        const data = await res.json();
        if (!res.ok) {
            showToast(data.message || "Booking failed");
            return;
        }

        showToast("Booking successful!");
        // update local bookings from API
        await loadBookings();
    } catch (e) {
        console.error(e);
        showToast("Error connecting to server");
    }
}

async function loadBookings() {
    const user = getUserFromLocal();
    if (!user) {
        bookingsContainer.innerHTML = "";
        noBookingsText.classList.remove("hidden");
        return;
    }
    try {
        const res = await fetch(`${API_BASE}/bookings`, {
            headers: {
                "X-Auth-User": user.username
            }
        });
        const bookings = await res.json();
        saveBookingsLocal(bookings);
        renderBookings(bookings);
    } catch (e) {
        console.error(e);
        const local = getBookingsLocal();
        renderBookings(local);
        showToast("Showing offline bookings from local storage");
    }
}

function renderBookings(bookings) {
    bookingsContainer.innerHTML = "";
    if (!bookings || bookings.length === 0) {
        noBookingsText.classList.remove("hidden");
        return;
    }
    noBookingsText.classList.add("hidden");

    bookings.forEach(trip => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <h3>${trip.destination}</h3>
            <p class="muted">${trip.description}</p>
            <p>Date: ${trip.startDate} to ${trip.endDate}</p>
            <p class="price">₹${trip.price.toLocaleString()}</p>
            <p class="muted small">Booking stored in your account.</p>
        `;
        bookingsContainer.appendChild(card);
    });
}

async function handleLogin() {
    const username = loginUsername.value.trim();
    const password = loginPassword.value.trim();

    if (!username || !password) {
        showToast("Enter username and password");
        return;
    }

    try {
        const res = await fetch(`${API_BASE}/auth/login`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();
        if (!res.ok) {
            showToast(data.message || "Login failed");
            return;
        }

        const user = {
            username: data.username,
            fullName: data.fullName,
            token: data.token
        };
        saveUserToLocal(user);
        updateAuthUI();
        showToast("Logged in successfully");
        showSection(tripsSection);
        await loadBookings();
    } catch (e) {
        console.error(e);
        showToast("Error connecting to server");
    }
}

async function handleRegister() {
    const fullName = regFullName.value.trim();
    const email = regEmail.value.trim();
    const username = regUsername.value.trim();
    const password = regPassword.value.trim();

    if (!fullName || !email || !username || !password) {
        showToast("Fill all registration fields");
        return;
    }

    try {
        const res = await fetch(`${API_BASE}/auth/register`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ fullName, email, username, password })
        });

        const data = await res.json();
        if (!res.ok) {
            showToast(data.message || "Registration failed");
            return;
        }

        showToast("Registration successful. Now login.");
    } catch (e) {
        console.error(e);
        showToast("Error connecting to server");
    }
}

function handleLogout() {
    clearUserLocal();
    updateAuthUI();
    renderBookings([]);
    showSection(homeSection);
    showToast("Logged out");
}

navHome.addEventListener("click", () => showSection(homeSection));
navTrips.addEventListener("click", () => {
    showSection(tripsSection);
    fetchTrips();
});
navBookings.addEventListener("click", async () => {
    showSection(bookingsSection);
    await loadBookings();
});

exploreBtn.addEventListener("click", () => {
    showSection(tripsSection);
    fetchTrips();
});

btnLogin.addEventListener("click", () => {
    showSection(authSection);
});

btnLogout.addEventListener("click", handleLogout);
loginSubmit.addEventListener("click", handleLogin);
registerSubmit.addEventListener("click", handleRegister);

// init
(async function init() {
    updateAuthUI();
    await fetchTrips();
    await loadBookings();
})();
